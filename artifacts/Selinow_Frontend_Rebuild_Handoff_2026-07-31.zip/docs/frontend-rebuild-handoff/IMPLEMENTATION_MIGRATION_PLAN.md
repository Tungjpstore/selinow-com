# Ke hoach xay va migrate frontend moi

## Nguyen tac cutover

Khong big-bang replace. Xay theo vertical slice, giu route/API contract, so sanh parity va co rollback bang deploy version. Khong sua backend chi de lam UI de hon neu chua co change request/test rieng.

## Giai doan 0 - Contract freeze

- Chot commit SHA lam baseline.
- Chay route/API/state inventory va cap nhat file may-doc.
- Danh dau moi capability theo `live/read_only/service_only/provider_pending/external_pending/roadmap`.
- Tao danh sach route khong duoc regression va error code bat buoc.
- Chot analytics/telemetry toi thieu ma khong ghi PII/secret.

Exit: 100% control trong wireframe co source authority hoac bi loai.

## Giai doan 1 - Foundations

- Tao token, typography, spacing, layout, focus, status va form primitives moi.
- Tao surface shell rieng cho marketing, workspace, storefront, admin.
- Tao safe API client pattern cho CSRF/idempotency/request ID/error mapping.
- Tao fixture tu safe projections, khong dung production data/secrets.
- Dat a11y/overflow/browser test harness truoc khi lam feature.

Exit: component primitives pass keyboard, axe, 320/390/768/1440 va reduced motion.

## Giai doan 2 - Public va auth

- Marketing `/`, `/pricing`, `/login`.
- Tenant storefront `/`, `/products/:slug` voi SSR/no-JS utility.
- Cart, checkout, order status theo server quote/order-token contract.
- Abuse report va safe errors.

Exit: public browser gate; khong mutation khi GET/HEAD; tenant hostname isolation; stale quote/stock drift fail closed.

## Giai doan 3 - Seller core

- Workspace shell, shop switch, `/app`, onboarding.
- Products, inventory, orders, order detail.
- Customers/members/billing doc dung projection va read-only boundary.
- Store builder/draft/publish, integrations/Telegram, domains, automation, data/audit.

Exit: role matrix, tenant switch reset, secret handling, state coverage va authenticated browser gate.

## Giai doan 4 - Admin

- Abuse/moderation overview.
- Shop directory read-only.
- Operations: deletion/legal hold, incident, DLQ, rotation theo exact role/version/recent-auth contract.

Exit: support/risk/owner matrix; destructive confirmations; no impersonation; safe evidence only.

## Giai doan 5 - Parallel run va cutover

- Chay full gates tren commit canary.
- So sanh route/status/header/cache/no-JS output giua old/new.
- Chay controlled canary chi frontend surface; khong tu kich hoat PayOS, Telegram, queue, fulfillment hoac external domain.
- Theo doi 4xx/5xx, CSP, JS console, request ID va business transition counts.
- Promote khi acceptance matrix pass; giu previous Worker version/asset build de rollback.

## Rollback triggers

Rollback ngay neu co mot trong cac dau hieu:

- cross-tenant data/route bleed;
- client co the danh dau paid/fulfilled hoac bypass signed evidence;
- secret/token/plaintext xuat hien trong HTML/log/storage/screenshot;
- checkout tao duplicate order/reservation do sai idempotency;
- 403/503 fallback thanh data/action cua role cu;
- public catalog mat SSR/no-JS utility;
- critical route 5xx, CSP block bundle, overflow/ngat action tren 320/390;
- provider/payment/domain activation bi thay doi ngoai ke hoach frontend.

## Verification gate

```bash
npm run check
npm run lint
npm run test
npm run build
npm run deploy:dry-run
```

Them browser gates phu hop route da thay. Production deploy can theo `docs/PRODUCTION_RELEASE.md` va guarded release scripts, khong goi Wrangler truc tiep de bo qua admission.

